import os
import pickle
import numpy as np
import cv2
import face_recognition
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = "supersecretkey"

with open('trained_svm_model.pkl', 'rb') as f:
    clf = pickle.load(f)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'webcam' in request.form:
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            cap.release()
            if ret:
                cv2.imwrite('static/captured.jpg', frame)
                image_path = 'static/captured.jpg'
            else:
                flash("Webcam capture failed.")
                return redirect(request.url)
        elif 'image' in request.files:
            file = request.files['image']
            if file.filename == '' or not allowed_file(file.filename):
                flash("No valid image selected.")
                return redirect(request.url)
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])
            filename = secure_filename(file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(image_path)
        else:
            flash("No image provided.")
            return redirect(request.url)

        image = face_recognition.load_image_file(image_path)
        face_locations = face_recognition.face_locations(image)
        face_encodings = face_recognition.face_encodings(image, face_locations)
        
        results = []
        for encoding, (top, right, bottom, left) in zip(face_encodings, face_locations):
            predicted_name = clf.predict([encoding])[0]
            probability = np.max(clf.predict_proba([encoding]))
            results.append({
                'name': predicted_name,
                'probability': float(probability),
                'location': (top, right, bottom, left)
            })

        return render_template("result.html", results=results, image_path=image_path)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)


